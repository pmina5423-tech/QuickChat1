package com.prog5121;

import java.util.regex.Pattern;

/**
 * This class handles everything related to registering a new user.
 * I wrote three validation methods to check the username, password,
 * and cell phone number before allowing registration to go through.
 *
 * @author Pretext Mina Mkhondo
 * @version 2.0
 */
public class Registration {

    // I store the user's details here after a successful registration
    private String registeredUsername;
    private String registeredPassword;
    private String registeredPhoneNumber;

    /**
     * I use this method to check if the username is valid.
     * The username must have an underscore and be 5 characters or fewer.
     *
     * @param username the username the user wants to register with
     * @return true if the username passes both checks, false if not
     */
    public boolean checkUserName(String username) {
        // I return false immediately if the username is empty or null
        if (username == null || username.isEmpty()) {
            return false;
        }

        boolean hasUnderscore   = username.contains("_");
        boolean isCorrectLength = username.length() <= 5;
        return hasUnderscore && isCorrectLength;
    }

    /**
     * I use this method to check that the password is strong enough.
     * The password must be at least 8 characters and contain:
     * an uppercase letter, a lowercase letter, a number, and a special character.
     *
     * @param password the password the user wants to use
     * @return true if the password meets all the rules, false otherwise
     */
    public boolean checkPasswordComplexity(String password) {
        // I reject the password straight away if it is null or too short
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasUppercase = password.chars().anyMatch(Character::isUpperCase);
        boolean hasLowercase = password.chars().anyMatch(Character::isLowerCase);
        boolean hasDigit     = password.chars().anyMatch(Character::isDigit);
        boolean hasSpecial   = password.chars().anyMatch(ch -> !Character.isLetterOrDigit(ch));

        return hasUppercase && hasLowercase && hasDigit && hasSpecial;
    }

    /**
     * I use this method to check if the phone number is a valid South African
     * cell phone number. I researched the regex pattern online and adapted it.
     *
     * Regex source I used and adapted:
     * https://stackoverflow.com/questions/23715881/south-african-phone-number-regex
     *
     * @param phoneNumber the cell number the user entered
     * @return true if the number matches the SA cell phone pattern, false if not
     */
    public boolean checkCellPhoneNumber(String phoneNumber) {
        // I return false right away if nothing was entered
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return false;
        }

        // I import and use Pattern from java.util.regex as Miss B instructed
        // Source: https://stackoverflow.com/questions/23715881/south-african-phone-number-regex
        String saPhoneRegex = "^(\\+27|0)[6-8][0-9]{8}$";
        return Pattern.matches(saPhoneRegex, phoneNumber);
    }

    /**
     * This method brings all three checks together.
     * I validate each field in order and return an error message
     * as soon as one fails, otherwise I save the user's details.
     *
     * @param username    the username to register
     * @param password    the password to register
     * @param phoneNumber the cell phone number to register
     * @return a message telling the user if registration worked or what went wrong
     */
    public String registerUser(String username, String password, String phoneNumber) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username "
                 + "contains an underscore and is no more than 5 characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password "
                 + "contains at least 8 characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(phoneNumber)) {
            return "Cell phone number incorrectly formatted or does not exist.";
        }

        this.registeredUsername    = username;
        this.registeredPassword    = password;
        this.registeredPhoneNumber = phoneNumber;

        return "Registration successful!";
    }

    // I provide getters so the Login class can access the stored credentials
    public String getRegisteredUsername()    { return registeredUsername; }
    public String getRegisteredPassword()    { return registeredPassword; }
    public String getRegisteredPhoneNumber() { return registeredPhoneNumber; }
}
