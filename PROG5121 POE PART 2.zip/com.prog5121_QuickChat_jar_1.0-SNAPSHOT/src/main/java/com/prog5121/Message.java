package com.prog5121;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a single message in the QuickChat application.
 * I handle message creation, validation, hash generation, sending,
 * storing to a JSON file, and displaying message details.
 *
 * @author Pretext Mina Mkhondo
 * 
 * @version 2.0
 */
public class Message {

    // I define constants so I avoid magic numbers throughout the class
    private static final int    MAX_MESSAGE_LENGTH = 250;
    private static final int    MAX_CELL_LENGTH    = 12;
    private static final String JSON_FILE_PATH     = "messages.json";

    // I store each message's details in these instance fields
    private String messageID;
    private int    messageNumber;
    private String recipient;
    private String message;
    private String messageHash;

    // I use static fields to track ALL messages across the session
    private static int           totalMessages = 0;
    private static List<Message> sentMessages  = new ArrayList<>();

    // =========================================================================
    // CONSTRUCTOR
    // I accept recipient and message as inputs and auto-generate
    // the messageID, messageNumber, and messageHash in the constructor.
    // =========================================================================
    public Message(String recipient, String message) {
        this.recipient = recipient;
        this.message   = message;

        // I auto-increment the total messages counter
        totalMessages++;

        // I set the message number to the current total
        this.messageNumber = totalMessages;

        // I auto-generate the message ID using string manipulation
        this.messageID = generateMessageID();

        // I auto-generate the message hash using string manipulation
        this.messageHash = createMessageHash();
    }

    /**
     * I generate a unique 10-character message ID using string manipulation.
     * I use the message number as a 2-char prefix and append 8 random digits.
     * I use substring — string manipulation — to get exactly 10 characters.
     *
     * @return a 10-character unique message ID
     */
    private String generateMessageID() {
        // I use String.format to create a 2-char zero-padded prefix
        String prefix = String.format("%02d", messageNumber);

        // I generate 8 random digits to make the ID unique
        int    randomNum  = (int) (Math.random() * 90000000) + 10000000;
        String randomPart = String.valueOf(randomNum);

        // I combine and use substring — string manipulation
        String fullID = prefix + randomPart;
        return fullID.substring(0, 10);
    }

    /**
     * I check that the message ID is not more than 10 characters long.
     *
     * @return true if valid, false if too long or null
     */
    public boolean checkMessageID() {
        if (messageID == null || messageID.isEmpty()) {
            return false;
        }
        return messageID.length() <= 10;
    }

    /**
     * I validate the recipient cell number.
     * It must be 10 characters or fewer and start with + for international code.
     *
     * @return success or failure message string
     */
    public String checkRecipientCell() {
        if (recipient == null || recipient.isEmpty()) {
            return "Cell phone number is incorrectly formatted or does not contain "
                 + "an international code. Please correct the number and try again.";
        }

        String cleaned = recipient.replaceAll("\\s+", "");

        if (!cleaned.startsWith("+")) {
            return "Cell phone number is incorrectly formatted or does not contain "
                 + "an international code. Please correct the number and try again.";
        }

        String digitsOnly = cleaned.substring(1);
        if (!digitsOnly.matches("\\d+")) {
            return "Cell phone number is incorrectly formatted or does not contain "
                 + "an international code. Please correct the number and try again.";
        }

        if (cleaned.length() > MAX_CELL_LENGTH) {
            return "Cell phone number is incorrectly formatted or does not contain "
                 + "an international code. Please correct the number and try again.";
        }

        return "Cell phone number successfully captured.";
    }

    /**
     * I validate that the message does not exceed 250 characters.
     *
     * @return "Message sent" on success, error string on failure
     */
    public String checkMessageLength() {
        if (message == null) {
            return "Please enter a message of less than 250 characters.";
        }

        if (message.length() > MAX_MESSAGE_LENGTH) {
            int excess = message.length() - MAX_MESSAGE_LENGTH;
            return "Message exceeds 250 characters by " + excess
                 + "; please reduce the size.";
        }

        return "Message sent";
    }

    /**
     * I auto-generate a message hash using string manipulation and loop counter.
     *
     * Format: XX:Y:FIRSTWORDLASTWORD (all uppercase)
     * XX    = first 2 characters of message ID (substring)
     * Y     = message number (loop counter)
     * FIRST = first word of message (split + replaceAll)
     * LAST  = last word of message  (split + replaceAll)
     *
     * Example: "Hi Mike, can you join us for dinner tonight?" = HITONIGHT
     *
     * @return the generated message hash in uppercase
     */
    public String createMessageHash() {
        if (messageID == null || message == null) {
            return "INVALID HASH";
        }

        // I use substring to get first 2 chars of message ID
        String idPart = messageID.length() >= 2
                ? messageID.substring(0, 2)
                : String.format("%02d", messageNumber);

        // I use the message number as the middle part
        String numPart = String.valueOf(messageNumber);

        // I split and strip punctuation from first and last words
        String[] words     = message.trim().split("\\s+");
        String   firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String   lastWord  = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");

        // I build and force uppercase
        messageHash = (idPart + ":" + numPart + ":" + firstWord + lastWord).toUpperCase();
        return messageHash;
    }

    /**
     * I let the user choose: Send (1), Disregard (2), or Store (3).
     *
     * @param choice the user's selection
     * @return a confirmation message
     */
    public String sentMessage(String choice) {
        switch (choice.trim()) {
            case "1":
                sentMessages.add(this);
                return "Message successfully sent.";

            case "2":
                return "Press 0 to delete the message.";

            case "3":
                storeMessage();
                return "Message successfully stored.";

            default:
                return "Invalid option. Please select 1, 2, or 3.";
        }
    }

    /**
     * I store this message to a JSON file using plain Java FileWriter.
     * I manually build the JSON string so no external library is needed.
     */
    public void storeMessage() {
        String existingContent = "";
        File   file            = new File(JSON_FILE_PATH);

        if (file.exists()) {
            try {
                existingContent = new String(Files.readAllBytes(Paths.get(JSON_FILE_PATH)));
                existingContent = existingContent.trim();
                if (existingContent.endsWith("]")) {
                    existingContent = existingContent
                            .substring(0, existingContent.length() - 1) + ",\n";
                }
            } catch (IOException e) {
                System.err.println("Error reading JSON file: " + e.getMessage());
                existingContent = "";
            }
        }

        String jsonEntry = "  {\n"
                + "    \"messageID\": \""     + messageID                               + "\",\n"
                + "    \"messageHash\": \""   + (messageHash != null ? messageHash : "") + "\",\n"
                + "    \"recipient\": \""     + (recipient   != null ? recipient   : "") + "\",\n"
                + "    \"message\": \""       + (message     != null ? message     : "") + "\",\n"
                + "    \"messageNumber\": \"" + messageNumber                           + "\"\n"
                + "  }";

        try (FileWriter writer = new FileWriter(JSON_FILE_PATH)) {
            if (existingContent.isEmpty()) {
                writer.write("[\n" + jsonEntry + "\n]");
            } else {
                writer.write(existingContent + jsonEntry + "\n]");
            }
        } catch (IOException e) {
            System.err.println("Error writing to JSON file: " + e.getMessage());
        }
    }

    /**
     * I return the message details in the required order:
     * Message ID → Message Hash → Recipient → Message
     *
     * @return formatted string of message details
     */
    public String printMessages() {
        return  "Message ID:   " + messageID   + "\n" +
                "Message Hash: " + messageHash + "\n" +
                "Recipient:    " + recipient   + "\n" +
                "Message:      " + message;
    }

    /**
     * I return the total number of messages sent during this session.
     *
     * @return total messages count
     */
    public static int returnTotalMessages() {
        return totalMessages;
    }

    // ── Getters and Setters ───────────────────────────────────────────────────

    public String getMessageID()              { return messageID; }
    public void   setMessageID(String id)     { this.messageID = id; }

    public String getRecipient()              { return recipient; }
    public void   setRecipient(String r)      { this.recipient = r; }

    public String getMessage()                { return message; }
    public void   setMessage(String msg)      { this.message = msg; }

    public String getMessageHash()            { return messageHash; }
    public void   setMessageHash(String hash) { this.messageHash = hash; }

    public int    getMessageNumber()          { return messageNumber; }
    public void   setMessageNumber(int n)     { this.messageNumber = n; }

    public static void          resetTotalMessages() { totalMessages = 0; sentMessages.clear(); }
    public static List<Message> getSentMessages()    { return sentMessages; }
}
