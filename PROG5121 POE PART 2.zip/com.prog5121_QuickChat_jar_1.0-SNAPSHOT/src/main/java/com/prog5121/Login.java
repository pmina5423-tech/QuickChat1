package com.prog5121;

/**
 * This class handles the login process for a registered user.
 * I check the username and password against what was saved during
 * registration and I return a message to tell the user what happened.
 *
 * @author Pretext Mina Mkhondo
 * @version 2.0
 */
public class Login {

    // I only allow 3 attempts before locking the account
    private static final int MAX_ATTEMPTS = 3;

    private final Registration registration;
    private int     loginAttempts;
    private boolean isLoggedIn;

    /**
     * I pass in the Registration object so I can access the saved credentials.
     *
     * @param registration the Registration object that holds the user's details
     */
    public Login(Registration registration) {
        this.registration  = registration;
        this.loginAttempts = 0;
        this.isLoggedIn    = false;
    }

    /**
     * This is the main login method. I compare what the user typed against
     * what was saved during registration and give a specific message for
     * each outcome.
     *
     * @param username the username the user typed in
     * @param password the password the user typed in
     * @return a message telling the user if login worked or what went wrong
     */
    public String loginUser(String username, String password) {
        // I check that a user has actually registered first
        if (registration.getRegisteredUsername() == null) {
            return "No registered user found. Please register first.";
        }

        // I block further attempts if the account is already locked
        if (loginAttempts >= MAX_ATTEMPTS) {
            return "Account locked. Too many failed login attempts. Please contact support.";
        }

        // I handle null inputs safely before comparing
        if (username == null || password == null) {
            loginAttempts++;
            return buildErrorMessage();
        }

        boolean usernameMatch = username.equals(registration.getRegisteredUsername());
        boolean passwordMatch = password.equals(registration.getRegisteredPassword());

        if (usernameMatch && passwordMatch) {
            isLoggedIn    = true;
            loginAttempts = 0;
            return returnLoginStatus(username);

        } else if (!usernameMatch && !passwordMatch) {
            loginAttempts++;
            return "Username and password do not match our records. " + buildErrorMessage();

        } else if (!usernameMatch) {
            loginAttempts++;
            return "Username does not match our records. " + buildErrorMessage();

        } else {
            loginAttempts++;
            return "Password does not match our records. " + buildErrorMessage();
        }
    }

    /**
     * I build a personalised login success and welcome back message.
     * I extract the part of the username before the underscore and capitalise it.
     *
     * @param username the username that successfully logged in
     * @return a login success and welcome back message
     */
    public String returnLoginStatus(String username) {
        String displayName = username.contains("_")
                ? username.substring(0, username.indexOf("_"))
                : username;

        if (!displayName.isEmpty()) {
            displayName = Character.toUpperCase(displayName.charAt(0))
                        + displayName.substring(1).toLowerCase();
        }

        return "Login successfully.\nWelcome back " + displayName + "!";
    }

    /**
     * I tell the user how many login attempts they have left.
     *
     * @return a message showing remaining attempts or lockout notice
     */
    private String buildErrorMessage() {
        int remaining = MAX_ATTEMPTS - loginAttempts;
        if (remaining <= 0) {
            return "Account locked due to too many failed attempts.";
        }
        return "You have " + remaining + " attempt(s) remaining.";
    }

    public boolean isLoggedIn()       { return isLoggedIn; }
    public int     getLoginAttempts() { return loginAttempts; }
}
