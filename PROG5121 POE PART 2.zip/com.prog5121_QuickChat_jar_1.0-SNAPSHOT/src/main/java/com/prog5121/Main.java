package com.prog5121;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * This is the main class that runs the entire QuickChat application.
 * I have included both Part 1 (Registration and Login) methods and
 * Part 2 (QuickChat messaging) methods in this one main class.
 * I clearly label each section so that both parts are easy to identify.
 *
 * @author Pretext Mina Mkhondo
 * @version 2.0
 */
public class Main {

    // I share one scanner across all methods to avoid resource leaks
    private static final Scanner scanner = new Scanner(System.in);

    // =========================================================================
    // ========================== PART 1 FIELDS ================================
    // =========================================================================

    // I store the registered user details in these static fields
    private static String registeredUsername;
    private static String registeredPassword;
    private static String registeredPhoneNumber;

    // I use this to track login attempts and login state
    private static int     loginAttempts = 0;
    private static boolean isLoggedIn    = false;

    // I only allow 3 login attempts before locking the account
    private static final int MAX_ATTEMPTS = 3;

    // =========================================================================
    // ========================== PART 2 FIELDS ================================
    // =========================================================================

    // I store how many messages the user wants to send
    private static int numMessages = 0;

    // =========================================================================
    // MAIN — entry point for the application
    // =========================================================================
    public static void main(String[] args) {

        System.out.println("==========================================");
        System.out.println("        Welcome to QuickChat              ");
        System.out.println("==========================================");

        boolean running = true;

        // I keep the main menu running until the user chooses to exit
        while (running) {
            System.out.println("\nWhat would you like to do?");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    // ── PART 1: Registration ──────────────────────────────
                    registerUser();
                    break;

                case "2":
                    // ── PART 1: Login ─────────────────────────────────────
                    loginUser();

                    // I only launch QuickChat if login was successful
                    if (isLoggedIn) {
                        runQuickChat();
                    }
                    break;

                case "3":
                    running = false;
                    System.out.println("Thank you for using the system. Goodbye!");
                    break;

                default:
                    System.out.println("That is not a valid option. Please enter 1, 2, or 3.");
            }
        }

        scanner.close();
    }

    // =========================================================================
    // ========================== PART 1 METHODS ===============================
    // =========================================================================

    /**
     * PART 1 — Registration Method.
     * I ask the user for their details and validate each one before saving.
     */
    private static void registerUser() {
        System.out.print("Enter a username (must have _ and be 5 chars or less): ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter a password (8+ chars, upper, lower, number, special): ");
        String password = scanner.nextLine().trim();

        System.out.print("Enter your SA cell number (e.g. 0821234567): ");
        String phone = scanner.nextLine().trim();

        System.out.println("\n" + registerUser(username, password, phone));
    }

    /**
     * PART 1 — registerUser
     * I validate the username, password, and phone number.
     * I save the details if all three pass validation.
     *
     * @param username    the username to register
     * @param password    the password to register
     * @param phoneNumber the cell phone number to register
     * @return a message telling the user if registration worked or what went wrong
     */
    public static String registerUser(String username, String password, String phoneNumber) {
        // I check the username first
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username "
                 + "contains an underscore and is no more than 5 characters in length.";
        }

        // Then I check the password
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password "
                 + "contains at least 8 characters, a capital letter, a number, and a special character.";
        }

        // Finally I check the phone number
        if (!checkCellPhoneNumber(phoneNumber)) {
            return "Cell phone number incorrectly formatted or does not exist.";
        }

        // I save the details if all three checks pass
        registeredUsername    = username;
        registeredPassword    = password;
        registeredPhoneNumber = phoneNumber;

        return "Registration successful!";
    }

    /**
     * PART 1 — checkUserName
     * I check that the username contains an underscore and is 5 chars or fewer.
     *
     * @param username the username to check
     * @return true if valid, false if not
     */
    public static boolean checkUserName(String username) {
        // I return false immediately if the username is null or empty
        if (username == null || username.isEmpty()) {
            return false;
        }

        boolean hasUnderscore   = username.contains("_");
        boolean isCorrectLength = username.length() <= 5;
        return hasUnderscore && isCorrectLength;
    }

    /**
     * PART 1 — checkPasswordComplexity
     * I check that the password is at least 8 characters and contains
     * an uppercase letter, a lowercase letter, a number, and a special character.
     *
     * @param password the password to check
     * @return true if valid, false if not
     */
    public static boolean checkPasswordComplexity(String password) {
        // I reject the password if it is null or too short
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasUppercase = password.chars().anyMatch(Character::isUpperCase);
        boolean hasLowercase = password.chars().anyMatch(Character::isLowerCase);
        boolean hasDigit     = password.chars().anyMatch(Character::isDigit);
        boolean hasSpecial   = password.chars().anyMatch(ch -> !Character.isLetterOrDigit(ch));

        return hasUppercase && hasLowercase && hasDigit && hasSpecial;
    }

    /**
     * PART 1 — checkCellPhoneNumber
     * I check that the phone number is a valid South African cell number.
     * I use a regex pattern that I researched and adapted.
     *
     * Regex source I used and adapted:
     * https://stackoverflow.com/questions/23715881/south-african-phone-number-regex
     *
     * @param phoneNumber the cell number to check
     * @return true if valid, false if not
     */
    public static boolean checkCellPhoneNumber(String phoneNumber) {
        // I return false if nothing was entered
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return false;
        }

        // I import and use Pattern from java.util.regex as Miss B instructed
        // This regex accepts both local (0) and international (+27) SA formats
        // Source: https://stackoverflow.com/questions/23715881/south-african-phone-number-regex
        String saPhoneRegex = "^(\\+27|0)[6-8][0-9]{8}$";
        return Pattern.matches(saPhoneRegex, phoneNumber);
    }

    /**
     * PART 1 — loginUser (console method)
     * I ask the user for their credentials and call the validation method.
     */
    private static void loginUser() {
        // I make sure the user has registered first
        if (registeredUsername == null) {
            System.out.println("You need to register before you can log in.");
            return;
        }

        System.out.print("Enter your username: ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter your password: ");
        String password = scanner.nextLine().trim();

        System.out.println("\n" + loginUser(username, password));
    }

    /**
     * PART 1 — loginUser
     * I compare the entered credentials against the saved registration details.
     * I give a specific message depending on what went wrong.
     *
     * @param username the username entered
     * @param password the password entered
     * @return a message telling the user if login worked or what went wrong
     */
    public static String loginUser(String username, String password) {
        // I check that a user has actually registered first
        if (registeredUsername == null) {
            return "No registered user found. Please register first.";
        }

        // I block further attempts if the account is already locked
        if (loginAttempts >= MAX_ATTEMPTS) {
            return "Account locked. Too many failed login attempts. Please contact support.";
        }

        // I handle null inputs safely
        if (username == null || password == null) {
            loginAttempts++;
            return buildErrorMessage();
        }

        boolean usernameMatch = username.equals(registeredUsername);
        boolean passwordMatch = password.equals(registeredPassword);

        if (usernameMatch && passwordMatch) {
            isLoggedIn    = true;
            loginAttempts = 0;
            return returnLoginStatus(username);

        } else if (!usernameMatch && !passwordMatch) {
            loginAttempts++;
            return "Username and password do not match our records. " + buildErrorMessage();

        } else if (!usernameMatch) {
            loginAttempts++;
            return "Username does not match our records. " + buildErrorMessage();

        } else {
            loginAttempts++;
            return "Password does not match our records. " + buildErrorMessage();
        }
    }

    /**
     * PART 1 — returnLoginStatus
     * I build a personalised login success and welcome back message.
     *
     * @param username the username that logged in successfully
     * @return a login success and welcome back message
     */
    public static String returnLoginStatus(String username) {
        // I extract the part before the underscore and capitalise it
        String displayName = username.contains("_")
                ? username.substring(0, username.indexOf("_"))
                : username;

        if (!displayName.isEmpty()) {
            displayName = Character.toUpperCase(displayName.charAt(0))
                        + displayName.substring(1).toLowerCase();
        }

        return "Login successfully.\nWelcome back " + displayName + "!";
    }

    /**
     * PART 1 — buildErrorMessage (private helper)
     * I tell the user how many login attempts they have left.
     *
     * @return a message showing remaining attempts or lockout notice
     */
    private static String buildErrorMessage() {
        int remaining = MAX_ATTEMPTS - loginAttempts;
        if (remaining <= 0) {
            return "Account locked due to too many failed attempts.";
        }
        return "You have " + remaining + " attempt(s) remaining.";
    }

    // ── Getters for tests ─────────────────────────────────────────────────────
    public static boolean isLoggedIn()            { return isLoggedIn; }
    public static int     getLoginAttempts()      { return loginAttempts; }
    public static String  getRegisteredUsername() { return registeredUsername; }

    // I provide a reset method so unit tests can reset the state between tests
    public static void resetState() {
        registeredUsername    = null;
        registeredPassword    = null;
        registeredPhoneNumber = null;
        loginAttempts         = 0;
        isLoggedIn            = false;
    }

    // =========================================================================
    // ========================== PART 2 METHODS ===============================
    // =========================================================================

    /**
     * PART 2 — runQuickChat
     * I run the QuickChat messaging section after a successful login.
     * I display the welcome message, ask how many messages to send,
     * then run the main menu in a WHILE LOOP until the user quits.
     * Rubric: while loop runs correctly and quits on correct input (option 3).
     */
    private static void runQuickChat() {

        // I display the welcome message as required by the assignment
        System.out.println("\nWelcome to QuickChat.");

        // I ask how many messages the user wants to send
        System.out.print("How many messages do you want to send? ");
        numMessages = readInt();

        // ── WHILE LOOP ──────────────────────────────────────────────────────
        // I keep the QuickChat menu running until the user selects 3 to quit.
        boolean running = true;
        while (running) {
            displayMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    // I call sendMessages which uses a FOR LOOP
                    sendMessages();
                    break;

                case "2":
                    // This feature is still in development
                    System.out.println("\nComing Soon.");
                    break;

                case "3":
                    // I display the total messages then exit cleanly
                    System.out.println("\nTotal messages sent: "
                            + Message.returnTotalMessages());
                    running = false;
                    System.out.println("Thank you for using QuickChat. Goodbye!");
                    break;

                default:
                    System.out.println("That is not a valid option. Please enter 1, 2, or 3.");
            }
        }
    }

    /**
     * PART 2 — displayMenu
     * I display the QuickChat numeric menu with options 1 through 3.
     * Rubric: numeric menu displayed, user chooses using numbers 1–3.
     */
    private static void displayMenu() {
        System.out.println("\n------------------------------------------");
        System.out.println("           Welcome to QuickChat           ");
        System.out.println("------------------------------------------");
        System.out.println("1) Send Messages");
        System.out.println("2) Show recently sent messages");
        System.out.println("3) Quit");
        System.out.println("------------------------------------------");
        System.out.print("Select an option: ");
    }

    /**
     * PART 2 — sendMessages
     * I use a FOR LOOP to let the user send the assigned number of messages.
     * I check if the limit has been reached before starting the loop.
     * Rubric: for loop runs for the assigned number and exits correctly.
     */
    private static void sendMessages() {
        System.out.println("\n=== Send Messages ===");

        // I check if the user has already reached their message limit
        if (Message.returnTotalMessages() >= numMessages) {
            System.out.println("You have reached your message limit of " + numMessages + ".");
            return;
        }

        // ── FOR LOOP — runs for the remaining number of messages ───────────
        int remaining = numMessages - Message.returnTotalMessages();
        for (int i = 0; i < remaining; i++) {

            System.out.println("\n--- Message " + (Message.returnTotalMessages() + 1)
                    + " of " + numMessages + " ---");

            // I ask for and validate the recipient cell number
            String  cell           = "";
            boolean validRecipient = false;

            while (!validRecipient) {
                System.out.print("Enter recipient cell number (e.g. +27123456789): ");
                cell = scanner.nextLine().trim();

                if (cell.isEmpty() || !cell.startsWith("+")) {
                    System.out.println("Cell phone number is incorrectly formatted or does "
                            + "not contain an international code. "
                            + "Please correct the number and try again.");
                } else {
                    validRecipient = true;
                }
            }

            // I ask for and validate the message text
            String  text         = "";
            boolean validMessage = false;

            while (!validMessage) {
                System.out.print("Enter your message (max 250 characters): ");
                text = scanner.nextLine();

                if (text.length() > 250) {
                    int excess = text.length() - 250;
                    System.out.println("Message exceeds 250 characters by " + excess
                            + "; please reduce the size.");
                } else {
                    validMessage = true;
                }
            }

            // I create the Message object — constructor auto-generates ID, number, hash
            Message message = new Message(cell, text);

            // I display the auto-generated message details
            System.out.println("Message ID generated: " + message.getMessageID());
            System.out.println(message.checkRecipientCell());
            System.out.println(message.checkMessageLength());
            System.out.println("Message Hash: " + message.getMessageHash());

            // I ask the user what they want to do with the message
            System.out.println("\nWhat would you like to do with this message?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Select: ");
            String sendChoice = scanner.nextLine().trim();

            System.out.println(message.sentMessage(sendChoice));

            // I display the full message details in the required order:
            // Message ID → Message Hash → Recipient → Message
            System.out.println("\n--- Message Details ---");
            System.out.println(message.printMessages());
        }

        // I display all sent messages and the total after the loop finishes
        // Rubric: full details of each message displayed after all are sent
        System.out.println("\n========================================");
        System.out.println("=== All Messages Sent This Session ===");
        System.out.println("========================================");
        for (Message sent : Message.getSentMessages()) {
            System.out.println(sent.printMessages());
            System.out.println("----------------------------------------");
        }
        System.out.println("Total messages sent: " + Message.returnTotalMessages());
    }

    /**
     * PART 2 — readInt (private helper)
     * I safely read an integer from the console and re-prompt on bad input.
     *
     * @return a valid integer entered by the user
     */
    private static int readInt() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}
