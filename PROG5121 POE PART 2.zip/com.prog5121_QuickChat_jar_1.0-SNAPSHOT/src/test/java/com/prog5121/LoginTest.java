package com.prog5121;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit testing class for validating Part 1 Registration and Login behaviour.
 * I test both the Registration class methods and the Main class methods
 * because Miss B said to have one main page with both Part 1 and Part 2.
 * I clearly label these as Part 1 tests as instructed by Miss B.
 *
 * @author Pretext Mina Mkhondo
 */
public class LoginTest {

    private Registration registrationService;
    private Login        authenticationService;

    @Before
    public void initialiseObjects() {
        registrationService   = new Registration();
        authenticationService = new Login(registrationService);
        // I reset the Main class state before each test
        Main.resetState();
    }

    @After
    public void tearDown() {
        registrationService   = null;
        authenticationService = null;
        Main.resetState();
    }

    // ========== PART 1: USERNAME VALIDATION TESTS — Registration class ==========

    @Test
    public void testUsernameIsValid() {
        assertTrue("Username with underscore and <= 5 chars should be valid",
                registrationService.checkUserName("kyl_1"));
    }

    @Test
    public void testUsernameIsInvalid_NoUnderscore() {
        assertFalse("Username without underscore should be invalid",
                registrationService.checkUserName("kyl1"));
    }

    @Test
    public void testUsernameIsInvalid_TooLong() {
        assertFalse("Username over 5 chars should be invalid",
                registrationService.checkUserName("john_doe"));
    }

    // ========== PART 1: USERNAME VALIDATION TESTS — Main class ==========

    @Test
    public void testMainCheckUserName_Valid() {
        assertTrue("Main.checkUserName should accept valid username",
                Main.checkUserName("kyl_1"));
    }

    @Test
    public void testMainCheckUserName_Invalid() {
        assertFalse("Main.checkUserName should reject username without underscore",
                Main.checkUserName("kyle1"));
    }

    // ========== PART 1: PASSWORD VALIDATION TESTS ==========

    @Test
    public void testPasswordIsValid() {
        assertTrue("Complex password should be valid",
                registrationService.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testPasswordIsInvalid_TooShort() {
        assertFalse("Short password should be invalid",
                registrationService.checkPasswordComplexity("Pass1!"));
    }

    @Test
    public void testPasswordIsInvalid_NoUppercase() {
        assertFalse("Password without uppercase should be invalid",
                registrationService.checkPasswordComplexity("password1!"));
    }

    @Test
    public void testPasswordIsInvalid_NoDigit() {
        assertFalse("Password without digit should be invalid",
                registrationService.checkPasswordComplexity("Password!"));
    }

    @Test
    public void testPasswordIsInvalid_NoSpecialChar() {
        assertFalse("Password without special character should be invalid",
                registrationService.checkPasswordComplexity("Password1"));
    }

    // ========== PART 1: MAIN PASSWORD VALIDATION TESTS ==========

    @Test
    public void testMainCheckPasswordComplexity_Valid() {
        assertTrue("Main.checkPasswordComplexity should accept valid password",
                Main.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testMainCheckPasswordComplexity_Invalid() {
        assertFalse("Main.checkPasswordComplexity should reject weak password",
                Main.checkPasswordComplexity("weak"));
    }

    // ========== PART 1: PHONE NUMBER VALIDATION TESTS ==========

    @Test
    public void testPhoneNumberIsValid_WithCountryCode() {
        assertTrue("SA phone with +27 should be valid",
                registrationService.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testPhoneNumberIsValid_WithoutCountryCode() {
        assertTrue("SA phone starting with 0 should be valid",
                registrationService.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testPhoneNumberIsInvalid_WrongFormat() {
        assertFalse("Invalid phone number format should be rejected",
                registrationService.checkCellPhoneNumber("12345"));
    }

    // ========== PART 1: REGISTRATION TESTS ==========

    @Test
    public void testRegistrationSuccess() {
        assertEquals("Registration successful!",
                registrationService.registerUser("kyl_1", "Password1!", "+27831234567"));
    }

    @Test
    public void testRegistrationFails_InvalidUsername() {
        assertTrue(registrationService.registerUser("kyle", "Password1!", "+27831234567")
                .contains("Username"));
    }

    @Test
    public void testRegistrationFails_InvalidPassword() {
        assertTrue(registrationService.registerUser("kyl_1", "weak", "+27831234567")
                .contains("Password"));
    }

    @Test
    public void testRegistrationFails_InvalidPhone() {
        assertTrue(registrationService.registerUser("kyl_1", "Password1!", "12345")
                .contains("incorrectly formatted"));
    }

    // ========== PART 1: MAIN REGISTRATION TESTS ==========

    @Test
    public void testMainRegisterUser_Success() {
        assertEquals("Registration successful!",
                Main.registerUser("kyl_1", "Password1!", "+27831234567"));
    }

    @Test
    public void testMainRegisterUser_InvalidUsername() {
        assertTrue(Main.registerUser("kyle", "Password1!", "+27831234567")
                .contains("Username"));
    }

    // ========== PART 1: LOGIN TESTS — Login class ==========

    @Test
    public void testLoginSuccess_ReturnsLoginSuccessfullyAndWelcomeBack() {
        registrationService.registerUser("kyl_1", "Password1!", "+27831234567");
        String result = authenticationService.loginUser("kyl_1", "Password1!");

        assertTrue("Should be logged in",              authenticationService.isLoggedIn());
        assertTrue("Should contain Login successfully", result.contains("Login successfully"));
        assertTrue("Should contain Welcome back",       result.contains("Welcome back"));
    }

    @Test
    public void testLoginFails_WrongPassword() {
        registrationService.registerUser("kyl_1", "Password1!", "+27831234567");
        String result = authenticationService.loginUser("kyl_1", "WrongPass1!");

        assertTrue("Should say password wrong",  result.contains("Password does not match"));
        assertFalse("Should not be logged in",   authenticationService.isLoggedIn());
    }

    @Test
    public void testLoginFails_WrongUsername() {
        registrationService.registerUser("kyl_1", "Password1!", "+27831234567");
        String result = authenticationService.loginUser("john_1", "Password1!");

        assertTrue("Should say username wrong", result.contains("Username does not match"));
    }

    @Test
    public void testLoginFails_BothWrong() {
        registrationService.registerUser("kyl_1", "Password1!", "+27831234567");
        String result = authenticationService.loginUser("john_1", "WrongPass1!");

        assertTrue("Should say both wrong",
                result.contains("Username and password do not match"));
    }

    @Test
    public void testAccountLockoutAfterThreeAttempts() {
        registrationService.registerUser("kyl_1", "Password1!", "+27831234567");

        authenticationService.loginUser("kyl_1", "Wrong1!");
        authenticationService.loginUser("kyl_1", "Wrong2!");
        String lockResult = authenticationService.loginUser("kyl_1", "Wrong3!");

        assertTrue("Should warn account locked",
                lockResult.contains("Account locked due to too many failed attempts"));

        String blockedResult = authenticationService.loginUser("kyl_1", "Password1!");
        assertTrue("Should refuse login entirely",
                blockedResult.contains("Account locked. Too many failed login attempts"));
    }

    // ========== PART 1: MAIN LOGIN TESTS ==========

    @Test
    public void testMainLoginUser_Success() {
        Main.registerUser("kyl_1", "Password1!", "+27831234567");
        String result = Main.loginUser("kyl_1", "Password1!");

        assertTrue("Should be logged in",              Main.isLoggedIn());
        assertTrue("Should contain Login successfully", result.contains("Login successfully"));
        assertTrue("Should contain Welcome back",       result.contains("Welcome back"));
    }

    @Test
    public void testMainLoginUser_WrongPassword() {
        Main.registerUser("kyl_1", "Password1!", "+27831234567");
        String result = Main.loginUser("kyl_1", "WrongPass1!");

        assertFalse("Should not be logged in",   Main.isLoggedIn());
        assertTrue("Should say password wrong",  result.contains("Password does not match"));
    }

    @Test
    public void testMainReturnLoginStatus_ContainsWelcomeBack() {
        String result = Main.returnLoginStatus("kyl_1");
        assertTrue("Should contain Login successfully", result.contains("Login successfully"));
        assertTrue("Should contain Welcome back Kyl",   result.contains("Welcome back Kyl"));
    }
}
